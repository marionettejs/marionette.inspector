# Backbone.BabySitter

Copyright (C)2013 Derick Bailey, Muted Solutions, LLC

Distributed Under [MIT License](http://mutedsolutions.mit-license.org/)
