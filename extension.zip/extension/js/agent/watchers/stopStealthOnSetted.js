

// @private
var stopStealthOnSetted = function(watcher) {
    clearInterval(watcher);
};
