// @private
// Patcha la proprietà _events del componente dell'app
// (contiene gli handler degli eventi backbone)
var patchAppComponentEvents = _.bind(function(appComponent) {
    // TODO: funzione da rimuovere?
});
