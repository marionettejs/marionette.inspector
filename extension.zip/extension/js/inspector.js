// Script executed every time the devtools are opened.

// custom panel
chrome.devtools.panels.create("Marionette", "img/panel.png", "panel.html");
